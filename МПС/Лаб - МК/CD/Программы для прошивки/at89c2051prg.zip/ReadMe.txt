py2051.py   AT89C2051 Programmer   
10.06.2001 Dincer Aydin dinceraydin@altavista.net
www.geocities.com/dinceraydin/

Based on the DOS  programmer BlowIt  (C) 1996 Silicon Studio

To use this under winNT or Win 2k run InstallDriver.exe
to install the DLPortIO driver. You must be logged on
as ADMINISTRATOR to do this. 	

usage is:
py2051 fileName.hex portAddress
Port adres is optional.
Default port address is 0x378
Port address must be in hex.

Files in this archive:
ReadMe.txt		the file you are reading now
py2051.exe 		the programmer executable
py2051.py		the programmer source code
schematic.gif		schematic of the programmer
calldll.pyd		calldll library for Python Copyright 1996-2001 by Sam Rushing <rushing@nightmare.com> 
python21.dll		Python run time library
DLPORTIO.dll		DLPortIO Win32 DLL hardware I/O functions
DLPORTIO.sys	        Kernel mode driver for WinNT (not required for Win9x)
InstallDriver.exe	DLPortIO driver installer
ledblink.hex		Sample hex file
ledblink.asm		Source code of the sample 
ledCount.jpg		Schematic to test the programmed part
