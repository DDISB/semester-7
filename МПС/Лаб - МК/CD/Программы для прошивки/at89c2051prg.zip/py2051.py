# py2051.py   AT89C2051 Programmer   
# 10.06.2001 Dincer Aydin dinceraydin@altavista.net
# www.geocities.com/dinceraydin/
# 
# Based on the DOS  programmer BlowIt  (C) 1996 Silicon Studio
import sys,windll,time
ioport = windll.module('dlportio')

def inp(address):
	return ioport.DlPortReadPortUchar(address)
def out(address,data):
	ioport.DlPortWritePortUchar(address,data)

port= 0x378								# Default port address
inc_bit 	= 0x01
vpp_bit 	= 0x02
prog_bit 	= 0x04
erase_bit 	= 0x08
prog_mode	= 0x0f
erase_mode	= 0x07
idle		= 0x09

def delay(dur):							
	time.sleep(dur)

def blow():
	out(port,0xff)
	#Erase processor
	out(port+2,0x01)						
	delay(0.01)							# wait 10ms
	out(port+2,0x03)					# RST = 12
	delay(0.001)						# wait 1ms 
	out(port+2,erase_mode)				# RST = 12, PROG = H
	delay(0.001)						# wait 1ms
	out(port+2,erase_mode ^ prog_bit)	# P3.2 = 0
	delay(0.012)						# wait 12ms
	#This is ERASE PULSE!
	out(port+2,erase_mode)				# P3.2 = 1
	delay(0.012)						# wait 12ms
	out(port+2,erase_mode ^ vpp_bit)	# RST = 0
	delay(0.012)						# wait 20ms
	# Program Rom
	out(port+2,idle)
	delay(0.01)							# wait 10ms
	out(port+2,idle | vpp_bit)
	delay(0.01)							# wait 10ms
	out(port+2,prog_mode)				# RST = 12, PROG = H
	delay(0.001)						# wait 1ms
	print "Blowing..."
	k = l = 0
	for i in range(0,2048):
		if hexVals.has_key(i):			# program byte, skip if 0xFF (blank location)
			out(port,hexVals[i])
			delay(0.000002)					# wait 2us
			out(port+2,prog_mode ^ prog_bit)# P3.2 = 0	
			delay(0.000005)					# wait 5us
			out(port+2,prog_mode)			# P3.2 = 1
			delay(0.000002)
			q = 0
			while (inp(port+1) & 64) == 0:
				delay(0.00001)
				if q > 200:
					print "Never Ready ? Programming aborted."
					sys.exit()
				if q > k: 
					k = q
				q += 1 		
			if l > 30: 
				print"Error, no device ? Programming aborted."
				sys.exit()
			if q == 0:
				l += 1
			delay(0.000002)	
		out(port+2,prog_mode ^ inc_bit)
		delay(0.000005)
		out(port+2,prog_mode)
		delay(0.000002)
	out(port,0xff)
	delay(0.001)
	out(port+2,prog_mode ^ vpp_bit)
	delay(0.001)
	out(port+2,idle)
	out(port+2,0)
	print "We are finished !"    

if __name__ == '__main__':
	print "----------- AT89C2051 Programmer -----------"
	if len(sys.argv) < 2 :
		print "usage: py2051 fileName.hex portAddress"
		print "Port adres is optional."
		print "Default port address is 0x378."
		raw_input("")
		sys.exit()
	else:
		try:
			hexFile = open(sys.argv[1], 'r')
		except IOError:
			print 'cannot open file ', sys.argv[1]
			raw_input("usage: py2051 fileName.hex portAddress")
			sys.exit()
		else:
			hexLnsList = hexFile.readlines()
			hexFile.close()
	if len(sys.argv) == 3 :
		port = int(sys.argv[2],16)
		if port < 0x278:
			print "Wrong port address !"
			sys.exit()

	hexVals = {}
	for i in range(len(hexLnsList)):
		tmp = hexLnsList[i].strip()
		numOfBytes = int(hexLnsList[i][1:3],16) 
		startAdr = int(hexLnsList[i][3:7],16)
		for j in range(0,numOfBytes*2,2):
			hexVals[startAdr] = int(hexLnsList[i][9+j:11+j],16)
			startAdr += 1
	print "Got", len(hexVals), "bytes"

	blow()






